
import React from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';

const Floor = ({ position, color, children }) => {
  return (
    <mesh position={position}>
      <boxGeometry args={[10, 1, 10]} />
      <meshStandardMaterial color={color} />
      {children}
    </mesh>
  );
};

const PetZone = ({ name, position, color }) => {
  return (
    <group position={position}>
      <Floor position={[0, 0, 0]} color={color} />
      <mesh position={[0, 0.5, 0]}>
        <textGeometry args={[name, { font: 'helvetiker', size: 1, height: 0.1 }]} />
        <meshBasicMaterial color="black" />
      </mesh>
    </group>
  );
};

function App() {
  return (
    <Canvas camera={{ position: [0, 5, 15], fov: 50 }}>
      <ambientLight />
      <pointLight position={[10, 10, 10]} />
      <OrbitControls />

      <PetZone name="Dogs" position={[0, 0, 0]} color="brown" />
      <PetZone name="Cats" position={[12, 0, 0]} color="grey" />
      <PetZone name="Fish" position={[24, 0, 0]} color="blue" />
      <PetZone name="Birds" position={[0, 0, 12]} color="green" />
      <PetZone name="Rodents" position={[12, 0, 12]} color="pink" />
      <PetZone name="Reptiles" position={[24, 0, 12]} color="yellow" />
    </Canvas>
  );
}

export default App;
